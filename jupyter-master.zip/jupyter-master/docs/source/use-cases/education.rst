Jupyter in Education
====================

.. note::
    We're actively working on this section of the documentation to improve
    it for you. Thanks for your patience.