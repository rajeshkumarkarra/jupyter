A Visual Overview of Projects
=============================

**A high level visual overview of project relationships**


.. image:: ../_static/_images/repos_map.png
   :width: 75%
   :alt: Architecture diagram of project relationships
