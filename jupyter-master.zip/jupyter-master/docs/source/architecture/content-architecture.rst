Architecture Guides
===================

.. toctree::
   :maxdepth: 1

   how_jupyter_ipython_work
   visual_overview