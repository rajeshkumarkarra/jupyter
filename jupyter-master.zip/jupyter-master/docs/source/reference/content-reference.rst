Reference
=========

.. toctree::
   :maxdepth: 1

   mimetype.md
   ../glossary


Resources
---------

- :ref:`genindex`
- :ref:`search`